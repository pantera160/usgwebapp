var app = angular.module("ReturnRatio", ['chart.js', 'ngDialog'])
app.service('ReturnService', function($http) {
	this.getData = function() {
		// $http() returns a $promise that we can add handlers with .then()
		return $http({
			method: 'GET',
			url: 'http://localhost:8080/USGFinanceWebapp/rest/data/return',
			cache : true
		});
	};
	this.getCompany = function(){
		// $http() returns a $promise that we can add handlers with .then()
		return $http({
			method: 'GET',
			url: 'http://localhost:8080/USGFinanceWebapp/rest/data/company',
			cache : true
		});
	};
});

app.service('helpService', function(ngDialog){
	this.showHelp = function(controller){
		console.log('showHelp called');
		if(angular.equals(controller, 'equity')){
			ngDialog.open({
				template : 'equitytemplate', className: 'ngdialog-theme-default'
			});
		}
		else if(angular.equals(controller, 'assets')){
			ngDialog.open({
				template : 'assetstemplate', className: 'ngdialog-theme-default'
			});
		}
	};
});
app.filter('NumberEU', function() {
	/**
	 * Number.prototype.format(n, x, s, c)
	 *
	 * @param integer n: length of decimal
	 * @param integer x: length of whole part
	 * @param mixed   s: sections delimiter
	 * @param mixed   c: decimal delimiter
	 */
	Number.prototype.format = function(n, x, s, c) {
		var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\D' : '$') + ')',
			num = this.toFixed(Math.max(0, ~~n));
		return (c ? num.replace('.', c) : num).replace(new RegExp(re, 'g'), '$&' + (s || ','));
	};
	
	return function(input, para1) {
		var out = Number(input).format(1, 3, '.', ',');
		return out;
	}
});
app.controller('headerCtrl', ['$scope', 'ReturnService', function($scope, ReturnService){
	$scope.company = {};
	ReturnService.getCompany().then(function(result){
		$scope.company.name = result.data.company;
		$scope.company.sector = result.data.sector;
	})
}]);

app.controller('EquityCtrl', ['$scope', 'ReturnService', 'helpService', function($scope, ReturnService, helpService) {
	$scope.help = function(){
		console.log('help called');
		helpService.showHelp('equity');
	};
	$scope.options = {
		scaleShowVerticalLines: false
	};
	var sectorAvgE;
	//Array which contains the colours from each bar. If no colour is found bar will be grayish. Not standard in Chart.js!
	//Edited chart.js 2138, 2141, 2142.
	var colourArray = ["#D4FFEA"];
	$scope.data = [[]];
	$scope.labels = [];
	ReturnService.getData().then(function(result) {
		angular.forEach(result.data, function($value) {
			if(parseInt($value.year) > 0){
				$scope.data[0].push(round($value.roe*100));
				$scope.labels.push($value.year);
				colourArray.push("#EAF1F5");
			}
			else{
				$scope.data[0].unshift(round($value.roe*100));
				sectorAvgE = round($value.roe*100);
				$scope.labels.unshift("Sector Average");
			}
		});
		//Add colours array to correct syntax for charts
		$scope.colours = [{fillColor: colourArray}];
	});

	$scope.options = {
		scaleLabel: function(valuePayload) {
			return Number(valuePayload.value).toFixed(1) + '%';
		}
	};
	$scope.condition = function(item){
		if(item >= (sectorAvgE*0.95)){
			return "IMG/green.png";
		}
		else if(item >= (sectorAvgE*0.85)){
			return "IMG/orange.png";
		}
		else{
			return "IMG/red.png";
		}
	};
}]);
app.controller('AssetsCtrl', ['$scope', 'ReturnService', 'helpService', function($scope, ReturnService, helpService) {
	$scope.help = function(){
		console.log('help called');
		helpService.showHelp('assets');
	};
	$scope.options = {
		scaleShowVerticalLines: false
	};
	$scope.data = [[]];
	$scope.labels = [];
	var sectorAvgA;
	//Array which contains the colours from each bar. If no colour is found bar will be grayish. Not standard in Chart.js!
	//Edited chart.js 2138, 2141, 2142.
	var colourArray = ["#D4FFEA"];
	ReturnService.getData().then(function(result) {
		angular.forEach(result.data, function($value) {
			if($value.year > 0){
				$scope.data[0].push(round($value.roa*100));
				$scope.labels.push($value.year);
				colourArray.push("#EAF1F5");
			}
			else{
				$scope.data[0].unshift(round($value.roa*100));
				sectorAvgA = round($value.roa*100);
				$scope.labels.unshift("Sector Average");
			}
		});
		//Add colours array to correct syntax for charts
		$scope.colours = [{fillColor: colourArray}];
	});

	$scope.options = {
		scaleLabel: function(valuePayload) {
			return Number(valuePayload.value).toFixed(1) + '%';
		}
	};
	$scope.condition = function(item){
		if(item >= (sectorAvgA*0.95)){
			return "IMG/green.png";
		}
		else if(item >= (sectorAvgA*0.85)){
			return "IMG/orange.png";
		}
		else{
			return "IMG/red.png";
		}
	};
}]);
app.controller('ButtonsCtrl', function($scope) {
	//redirect to portal
	$scope.back = function() {
		window.location = "portal.html";
	};
});

var round = function(n){
	return Math.round(n * 10) / 10;
}