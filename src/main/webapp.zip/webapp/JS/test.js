var myApp = angular.module('test',['720kb.tooltips']);

myApp.controller('testCtrl', function($scope) {
    
});