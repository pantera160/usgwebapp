var app = angular.module('portal', []);

app.controller('portalCtrl', function($scope){
	
	$scope.back = function(){
		window.location = "index.html";
	};
});