var app = angular.module("WCMSavings", [])

app.service('WCMService', function($http) {
	this.getData = function() {
		// $http() returns a $promise that we can add handlers with .then()
		return $http({
			method: 'GET',
			url: 'http://localhost:8080/USGFinanceWebapp/rest/data/wcm'
		});
	};
	this.saveData = function($data){
		// $http() returns a $promise that we can add handlers with .then()
		return $http({
			method: 'POST',
			url: 'http://localhost:8080/USGFinanceWebapp/rest/data/wcm',
			data : $data
		});

	};
	this.getCompany = function(){
		// $http() returns a $promise that we can add handlers with .then()
		return $http({
			method: 'GET',
			url: 'http://localhost:8080/USGFinanceWebapp/rest/data/company',
			cache : true
		});
	};
	this.getTurnover = function(){
		// $http() returns a $promise that we can add handlers with .then()
		return $http({
			method: 'GET',
			url: 'http://localhost:8080/USGFinanceWebapp/rest/data/turnover',
			cache : true
		});
	}
});

app.filter('NumberEU', function() {
	/**
	 * Number.prototype.format(n, x, s, c)
	 *
	 * @param integer n: length of decimal
	 * @param integer x: length of whole part
	 * @param mixed   s: sections delimiter
	 * @param mixed   c: decimal delimiter
	 */
	Number.prototype.format = function(n, x, s, c) {
		var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\D' : '$') + ')',
			num = this.toFixed(Math.max(0, ~~n));
		return (c ? num.replace('.', c) : num).replace(new RegExp(re, 'g'), '$&' + (s || ','));
	};
	
	return function(input, para1) {
		var out = Number(input).format(1, 3, '.', ',');
		return out;
	}
});
app.directive('myNumberformat', function(){
	/**
	 * format(number, n, x, s, c)
	 *
	 * @param Number number: number to format
	 * @param integer n: length of decimal
	 * @param integer x: length of whole part
	 * @param mixed   s: sections delimiter
	 * @param mixed   c: decimal delimiter
	 */
	var format = function(number,n, x, s, c){
		var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\D' : '$') + ')',
			num = Number(number).toFixed(Math.max(0, ~~n));
		return (c ? num.replace('.', c) : num).replace(new RegExp(re, 'g'), '$&' + (s || ','));
	}
	
	var validNumber = function(number){
		return number.replace(',', '.');
	}
	
	return {
      require: 'ngModel',
      link: function(scope, element, attrs, ngModelController) {
        ngModelController.$parsers.push(function(data) {
          //convert data from view format to model format
          return validNumber(data); //converted
        });
    
        ngModelController.$formatters.push(function(data) {
          //convert data from model format to view format
          return format(data,1, 3, '.', ','); //converted
        });
      }
    };
});

app.controller('headerCtrl', ['$scope', 'WCMService', function($scope, WCMService){
	$scope.company = {};
	WCMService.getCompany().then(function(result){
		$scope.company.name = result.data.company;
		$scope.company.sector = result.data.sector;
	})
}]);

app.controller("WCMSCtrl", function($scope, WCMService){
	$scope.data = {};
	$scope.sector = {};
	$scope.back = function(){
		window.location = "portal.html";
	}
	
	var getSectorAvg =  function(){
		WCMService.getTurnover().then(function(result){
			angular.forEach(result.data, function(value){
				if(!(parseInt(value.year) > 0)){
					$scope.sector.dio = value.dio;
					$scope.sector.dso = value.dso;
					$scope.sector.dpo = value.dpo;
				}
			})
		});
	}
	
	var getData = function(){
		WCMService.getData().then(function(response){
			$scope.data = response.data;
		});
	}
	
	$scope.save = function(){
		WCMService.saveData($scope.data).then(function(result){
			$scope.data = result.data;
		});
		console.log('saved');
	};
	getData();
	getSectorAvg();
});


