var app = angular.module("BalansRatio", ['chart.js', 'ngDialog']);
app.service('BalansService', function($http) {
	this.getData = function() {
		// $http() returns a $promise that we can add handlers with .then()
		return $http({
			method: 'GET',
			url: 'http://localhost:8080/USGFinanceWebapp/rest/data/balans',
			cache: true
		});
	};
	this.getCompany = function(){
		// $http() returns a $promise that we can add handlers with .then()
		return $http({
			method: 'GET',
			url: 'http://localhost:8080/USGFinanceWebapp/rest/data/company',
			cache : true
		});
	};
});
app.service('helpService', function(ngDialog) {
	this.showHelp = function(controller) {
		console.log('showHelp called');
		if (angular.equals(controller, 'solvency')) {
			ngDialog.open({
				template: 'solvencytemplate',
				className: 'ngdialog-theme-default'
			});
		} else if (angular.equals(controller, 'currratio')) {
			ngDialog.open({
				template: 'currratiotemplate',
				className: 'ngdialog-theme-default'
			});
		} else if (angular.equals(controller, 'quickratio')) {
			ngDialog.open({
				template: 'quickratiotemplate',
				className: 'ngdialog-theme-default'
			});
		}
	};
});
app.filter('NumberEU', function() {
	/**
	 * Number.prototype.format(n, x, s, c)
	 *
	 * @param integer n: length of decimal
	 * @param integer x: length of whole part
	 * @param mixed   s: sections delimiter
	 * @param mixed   c: decimal delimiter
	 */
	Number.prototype.format = function(n, x, s, c) {
		var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\D' : '$') + ')',
			num = this.toFixed(Math.max(0, ~~n));
		return (c ? num.replace('.', c) : num).replace(new RegExp(re, 'g'), '$&' + (s || ','));
	};
	
	return function(input, para1) {
		var out = Number(input).format(1, 3, '.', ',');
		return out;
	}
});
app.controller('headerCtrl', ['$scope', 'BalansService', function($scope, BalansService){
	$scope.company = {};
	BalansService.getCompany().then(function(result){
		$scope.company.name = result.data.company;
		$scope.company.sector = result.data.sector;
	})
}]);

app.controller('SolvencyCtrl', ['$scope', 'BalansService', 'helpService', function($scope, BalansService, helpService) {
	$scope.help = function() {
		console.log('help called');
		helpService.showHelp('solvency');
	};
	$scope.options = {
		scaleShowVerticalLines: false
	};
	$scope.data = [
		[]
	];
	//Array which contains the colours from each bar. If no colour is found bar will be grayish. Not standard in Chart.js!
	//Edited chart.js 2138, 2141, 2142.
	var colourArray = ["#D4FFEA"];
	$scope.labels = [];
	BalansService.getData().then(function(result) {
		angular.forEach(result.data, function($value) {
			if (parseInt($value.year) > 0) {
				$scope.result = result.data;
				$scope.data[0].push(round($value.solvency * 100));
				$scope.labels.push($value.year);
				colourArray.push("#EAF1F5");
			} else {
				$scope.data[0].unshift(round($value.solvency));
				$scope.labels.unshift("Sector Average");
			}
		});
		//Add colours array to correct syntax for charts
		$scope.colours = [{
			fillColor: colourArray
		}];
	});
	$scope.options = {
		scaleLabel: function(valuePayload) {
			return Number(valuePayload.value).toFixed(1) + '%';
		}
	};
	$scope.condition = function(item){
		if(item >= 28.5){
			return "IMG/green.png";
		}
		else if(item >= 25.5){
			return "IMG/orange.png";
		}
		else{
			return "IMG/red.png";
		}
	}
}]);
app.controller('CurrRatioCtrl', ['$scope', 'BalansService', 'helpService', function($scope, BalansService, helpService) {
	$scope.help = function() {
		helpService.showHelp('currratio');
	};
	$scope.options = {
		scaleShowVerticalLines: false
	};
	$scope.data = [
		[]
	];
	//Array which contains the colours from each bar. If no colour is found bar will be grayish. Not standard in Chart.js!
	//Edited chart.js 2138, 2141, 2142.
	var colourArray = ["#D4FFEA"];
	$scope.labels = [];
	BalansService.getData().then(function(result) {
		angular.forEach(result.data, function($value) {
			if (parseInt($value.year) > 0) {
				$scope.data[0].push(round($value.currRatio * 100));
				$scope.labels.push($value.year);
				colourArray.push("#EAF1F5");
			} else {
				$scope.data[0].unshift(round($value.currRatio));
				$scope.labels.unshift("Sector Average");
			}
		});
		//Add colours array to correct syntax for charts
		$scope.colours = [{
			fillColor: colourArray
		}];
	});
	$scope.options = {
		scaleLabel: function(valuePayload) {
			return Number(valuePayload.value).toFixed(1) + '%';
		}
	};
	$scope.condition = function(item){
		if(item >= 118.75){
			return "IMG/green.png";
		}
		else if(item >= 106.25){
			return "IMG/orange.png";
		}
		else{
			return "IMG/red.png";
		}
	};
}]);
app.controller('QuickRatioCtrl', ['$scope', 'BalansService', 'helpService', function($scope, BalansService, helpService) {
	$scope.help = function() {
		helpService.showHelp('quickratio');
	};
	$scope.options = {
		scaleShowVerticalLines: false
	};
	$scope.data = [
		[]
	];
	//Array which contains the colours from each bar. If no colour is found bar will be grayish. Not standard in Chart.js!
	//Edited chart.js 2138, 2141, 2142.
	var colourArray = ["#D4FFEA"];
	$scope.labels = [];
	BalansService.getData().then(function(result) {
		angular.forEach(result.data, function($value) {
			if (parseInt($value.year) > 0) {
				$scope.data[0].push(round($value.quickRatio * 100));
				$scope.labels.push($value.year);
				colourArray.push("#EAF1F5");
			} else {
				$scope.data[0].unshift(round($value.quickRatio));
				$scope.labels.unshift("Sector Average");
			}
		});
		//Add colours array to correct syntax for charts
		$scope.colours = [{
			fillColor: colourArray
		}];
	});
	$scope.options = {
		scaleLabel: function(valuePayload) {
			return Number(valuePayload.value).toFixed(1) + '%';
		}
	};
	$scope.condition = function(item){
		if(item >= 95){
			return "IMG/green.png";
		}
		else if(item >= 85){
			return "IMG/orange.png";
		}
		else{
			return "IMG/red.png";
		}
	};
}]);
app.controller('ButtonsCtrl', function($scope) {
	//redirect to portal
	$scope.back = function() {
		window.location = "portal.html";
	};
});
var round = function(n) {
		return Math.round(n * 10) / 10;
	}