var app = angular.module("USGFinanceWebapp", []);
app.service('adminService', function($http) {
	this.getUsers = function() {
		// $http() returns a $promise that we can add handlers with .then()
		return $http({
			method: 'GET',
			url: 'http://localhost:8080/USGFinanceWebapp/rest/crm/users'
		});
	}
	this.resetMail = function($id) {
		// $http() returns a $promise that we can add handlers with .then()
		return $http({
			method: 'PUT',
			url: 'http://localhost:8080/USGFinanceWebapp/rest/crm/user/'+$id
		});
	}
	this.deleteUser = function($id) {
		// $http() returns a $promise that we can add handlers with .then()
		return $http({
			method: 'DELETE',
			url: 'http://localhost:8080/USGFinanceWebapp/rest/crm/user/'+$id
		});
	}
});

var.controller('adminCtrl', function($scope, adminService, $timeout){
	$scope.users = [];
	var getusers = function(){
		adminService.getUsers().then(function(result){
			$scope.users = result.data;
		});
	}
	
	$scope.deleteUser = function(id){
		adminService.deleteUser(id).succes(
			$scope.succes = true;
			$scope.text = "User has been succesfully removed."
			$timeout(function(){
				$scope.succes = false;
			}, 5000);
		)
	}
	
	$scope.reset = function(id){
		adminService.resetMail(id).then(function(result){
			$scope.succes = true;
			$scope.text = "Password from user "+result.data.name+" has been succesfully reset. \n A mail with the new password is sand to the email adress linked to this user."
			$timeout(function(){
				$scope.succes = false;
			})
			//TODO send email to result.data.email
		});
	}
	
	$scope.back = function(){
		window.location("index.html");
	}
});